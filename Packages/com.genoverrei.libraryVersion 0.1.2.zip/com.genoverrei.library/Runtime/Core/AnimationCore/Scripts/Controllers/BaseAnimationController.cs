using Genoverrei.Library.DesignPatternCore;
using UnityEngine;

namespace Genoverrei.Library.Core
{
    public abstract class BaseAnimationController : MonoBehaviour
    {
        protected StateMachine<AnimationContext> StateMachine;
        protected AnimationContext Context;

        protected virtual void Awake()
        {
            StateMachine = new StateMachine<AnimationContext>();
            Context = new AnimationContext();
        }

        protected virtual void Update() => StateMachine.Update();

        protected virtual void FixedUpdate() => StateMachine.FixedUpdate();
    }


}