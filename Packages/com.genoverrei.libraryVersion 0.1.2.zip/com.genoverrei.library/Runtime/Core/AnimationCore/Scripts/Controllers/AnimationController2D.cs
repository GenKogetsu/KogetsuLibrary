using System;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Animations;
using Genoverrei.Library.DesignPatternCore;

namespace Genoverrei.Library.Core
{
    [RequireComponent(typeof(MoveController2D))]
    public class AnimationController2D : BaseAnimationController
    {
        [Header("Settings")]
        public Animation2DMode AnimationMode;

        [Header("Directional Setup (Idle)")]
        public DirectionalAnimationData[] IdleAnimationArray; //new (เพิ่มช่องใส่ Idle)

        [Header("Directional Setup (Move)")]
        public DirectionalAnimationData[] MoveAnimationArray; //new (เปลี่ยนชื่อให้ชัดเจน)

        [Header("Directional Setup (Airborne)")]
        public DirectionalAnimationData[] JumpAnimationArray;
        public DirectionalAnimationData[] FallAnimationArray;

        [SerializeField] protected MoveController2D MoveController;

        protected override void Awake()
        {
            base.Awake();
            if (!MoveController && TryGetComponent(out MoveController2D mc)) MoveController = mc;

            Context.MoveContext = MoveController;
            Context.Mode = MoveController.DirectionMode;

            if (TryGetComponent(out Animator anim) || (anim = GetComponentInChildren<Animator>()) != null)
            {
                Context.MainAnimator = anim;
                Context.AnimationGraph = PlayableGraph.Create(gameObject.name + "_AnimGraph");
                Context.AnimationGraph.SetTimeUpdateMode(DirectorUpdateMode.GameTime);
                Context.PlayableOutput = AnimationPlayableOutput.Create(Context.AnimationGraph, "Animation", Context.MainAnimator);
            }

            //new (ส่งข้อมูล Idle เข้าไปด้วย)
            var directionalState = new DirectionalAnimationState(IdleAnimationArray, MoveAnimationArray, JumpAnimationArray, FallAnimationArray);
            directionalState.Initialize(Context);
            StateMachine.ChangeState(directionalState);
        }

        protected virtual void OnValidate()
        {
            if (MoveController != null)
            {
                int expected = MoveController.CountDirections();

                if (IdleAnimationArray == null || IdleAnimationArray.Length != expected)
                    Array.Resize(ref IdleAnimationArray, expected); //new (ปรับขนาดอัตโนมัติ)

                if (MoveAnimationArray == null || MoveAnimationArray.Length != expected)
                    Array.Resize(ref MoveAnimationArray, expected);

                if (JumpAnimationArray == null || JumpAnimationArray.Length != expected)
                    Array.Resize(ref JumpAnimationArray, expected);

                if (FallAnimationArray == null || FallAnimationArray.Length != expected)
                    Array.Resize(ref FallAnimationArray, expected);
            }
        }
    }
}