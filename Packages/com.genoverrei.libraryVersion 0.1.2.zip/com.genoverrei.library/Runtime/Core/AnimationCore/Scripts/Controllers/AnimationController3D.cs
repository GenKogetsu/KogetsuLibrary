using System;
using UnityEngine;
using Genoverrei.Library.DesignPatternCore;

namespace Genoverrei.Library.Core
{
    [RequireComponent(typeof(MoveController3D))]
    public class AnimationController3D : BaseAnimationController
    {
        


    }
}