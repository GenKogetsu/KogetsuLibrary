using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Animations;
using Genoverrei.Library.DesignPatternCore;

namespace Genoverrei.Library.Core
{
    public class DirectionalAnimationState : BaseState<AnimationContext>, IFixedUpdateState
    {
        private readonly DirectionalAnimationData[] _idleData;
        private readonly DirectionalAnimationData[] _moveData;
        private readonly DirectionalAnimationData[] _jumpData;
        private readonly DirectionalAnimationData[] _fallData;
        private readonly bool _useAirborneStates;
        private readonly bool _showDebug;

        private string _currentDebugState = "";

        public DirectionalAnimationState(
            DirectionalAnimationData[] idleData,
            DirectionalAnimationData[] moveData,
            DirectionalAnimationData[] jumpData,
            DirectionalAnimationData[] fallData,
            bool useAirborneStates = false,
            bool showDebug = true)
        {
            _idleData = idleData;
            _moveData = moveData;
            _jumpData = jumpData;
            _fallData = fallData;
            _useAirborneStates = useAirborneStates;
            _showDebug = showDebug;
        }

        void IFixedUpdateState.OnFixedUpdate()
        {
            if (Context.MoveContext == null) return;

            Vector3 currentDir = Context.MoveContext.CurrentDirection;
            bool isMoving = currentDir.sqrMagnitude > 0.01f;

            if (isMoving)
            {
                Context.MoveContext.LastFacingDirection = currentDir;
            }

            DirectionalAnimationData[] currentDataArray;
            string stateNameForDebug;

            if (_useAirborneStates && !Context.MoveContext.IsGrounded)
            {
                if (Context.MoveContext.VerticalVelocity > 0.05f)
                {
                    currentDataArray = _jumpData;
                    stateNameForDebug = "Jump";
                }
                else
                {
                    currentDataArray = _fallData;
                    stateNameForDebug = "Fall";
                }
            }
            else
            {
                if (isMoving)
                {
                    currentDataArray = _moveData;
                    stateNameForDebug = "Move";
                }
                else
                {
                    currentDataArray = _idleData;
                    stateNameForDebug = "Idle";
                }
            }

            if (_showDebug && _currentDebugState != stateNameForDebug)
            {
                Debug.Log($"[Animation] Changed State to: {stateNameForDebug}");
                _currentDebugState = stateNameForDebug;
            }

            if (currentDataArray == null || currentDataArray.Length == 0) return;

            Vector3 facingDir = Context.MoveContext.LastFacingDirection;

            //new (เพิ่มน้ำหนักแกน X เพื่อบังคับให้ ซ้าย-ขวา ชนะ บน-ล่าง เสมอเวลาเดินเฉียง ป้องกันแอนิเมชันกระตุก)
            Vector3 biasedFacingDir = new Vector3(facingDir.x * 1.1f, facingDir.y, facingDir.z).normalized;

            int bestMatch = 0;
            float maxDot = -1f;
            for (int i = 0; i < currentDataArray.Length; i++)
            {
                //new (ใช้ biasedFacingDir ที่ถูกถ่วงน้ำหนักแล้วมาเช็คหาทิศทางที่ดีที่สุด)
                float dot = Vector3.Dot(biasedFacingDir, currentDataArray[i].Direction.normalized);
                if (dot > maxDot)
                {
                    maxDot = dot;
                    bestMatch = i;
                }
            }

            var bestData = currentDataArray[bestMatch];

            if (Context.CurrentActiveModel != bestData.Model)
            {
                if (Context.CurrentActiveModel) Context.CurrentActiveModel.SetActive(false);
                Context.CurrentActiveModel = bestData.Model;
                if (Context.CurrentActiveModel) Context.CurrentActiveModel.SetActive(true);
            }

            if (Context.MainAnimator != null && bestData.Clip != null)
            {
                if (Context.CurrentClip != bestData.Clip)
                {
                    Context.CurrentClip = bestData.Clip;

                    if (Context.CurrentClipPlayable.IsValid())
                    {
                        Context.CurrentClipPlayable.Destroy();
                    }

                    Context.CurrentClipPlayable = AnimationClipPlayable.Create(Context.AnimationGraph, bestData.Clip);

                    //new (ย้ำความเร็วของ Clip กลับเป็น 1 เสมอกันเหนียว)
                    Context.CurrentClipPlayable.SetSpeed(1f);

                    Context.PlayableOutput.SetSourcePlayable(Context.CurrentClipPlayable);

                    if (!Context.AnimationGraph.IsPlaying())
                    {
                        Context.AnimationGraph.Play();
                    }
                }
            }
        }
    }
}