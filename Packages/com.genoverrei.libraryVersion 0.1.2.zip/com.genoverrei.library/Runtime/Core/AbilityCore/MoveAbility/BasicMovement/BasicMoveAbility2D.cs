using Genoverrei.Library.DesignPatternCore;
using System;

namespace Genoverrei.Library.Core
{
    [Serializable]
    public class BasicMoveAbility2D : BaseMoveAbility2D, IEnterState, IExitState, IAbility
    {
        void IEnterState.OnEnter() => OnEnter();
        void IExitState.OnExit() => OnExit();

        protected virtual void OnEnter()
        {
            if (Context.InputObserverChannel != null) Context.InputObserverChannel.OnMoveChannel += SetInput;
            if (Context.InputObserverChannel != null) Context.InputObserverChannel.OnJumpChannel += ExecuteJump;
        }

        protected virtual void OnExit()
        {
            if (Context.InputObserverChannel != null) Context.InputObserverChannel.OnMoveChannel -= SetInput;
            if (Context.InputObserverChannel != null) Context.InputObserverChannel.OnJumpChannel -= ExecuteJump;
        }

        protected override void OnFixedUpdate()
        {
            base.OnFixedUpdate();

            if (Context == null || Context.Stats == null) return;

            Vector2 clampedInput = Vector2.ClampMagnitude(CurrentInput, 1f);

            Vector3 rawDirection = new(clampedInput.x, clampedInput.y, 0f);
            Context.CurrentDirection = Context.SnapDirection(rawDirection);

            Context.Rb2.linearVelocity = new Vector3(CurrentInput.x, CurrentInput.y , 0) * Context.Stats.GetMoveSpeed();
        }

        protected void ExecuteJump()
        {
            if (Context == null || Context.Stats == null) return;
            Context.Rb2.AddForce(Vector2.up * Context.Stats.GetJumpForce(), ForceMode2D.Impulse);
        }


    }
}
