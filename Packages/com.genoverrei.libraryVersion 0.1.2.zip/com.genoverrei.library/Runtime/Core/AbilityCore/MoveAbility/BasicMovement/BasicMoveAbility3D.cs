using System;
using Genoverrei.Library.DesignPatternCore;

namespace Genoverrei.Library.Core
{
    [Serializable]
    public class BasicMoveAbility3D : BaseMoveAbility3D, IEnterState , IExitState, IAbility
    {
        [Header("Movement Settings")]
        [SerializeField] protected bool EnableRotation = true;
        [SerializeField] protected float RotationSpeed = 15f;

        [Header("Ball Settings (Physics Rolling)")]
        [SerializeField] protected bool IsBallRolling = false;
        [SerializeField] protected float RollTorque = 10f;

        void IEnterState.OnEnter() => OnEnter();
        void IExitState.OnExit() => OnExit();

        protected virtual void OnEnter()
        {
            if (Context.InputObserverChannel != null) Context.InputObserverChannel.OnMoveChannel += SetInput;
            if (Context.InputObserverChannel != null) Context.InputObserverChannel.OnJumpChannel += ExecuteJump;
        }

        protected virtual void OnExit()
        {
            if (Context.InputObserverChannel != null) Context.InputObserverChannel.OnMoveChannel -= SetInput;
            if (Context.InputObserverChannel != null) Context.InputObserverChannel.OnJumpChannel -= ExecuteJump;
        }

        protected override void OnFixedUpdate()
        {
            base.OnFixedUpdate();

            if (Context?.Stats == null || Context.Rb == null) return;

            Vector2 clampedInput = Vector2.ClampMagnitude(CurrentInput, 1f);

            Vector3 rawDirection = new(clampedInput.x, 0f, clampedInput.y);
            Context.CurrentDirection = Context.SnapDirection(rawDirection);

            Transform camTransform = Camera.main.transform;
            Vector3 moveDirection = Vector3.zero;

            if (CurrentInput.sqrMagnitude > 0.001f)
            {
                Vector3 camForward = camTransform.forward;
                Vector3 camRight = camTransform.right;

                camForward.y = 0f;
                camRight.y = 0f;
                camForward.Normalize();
                camRight.Normalize();

                moveDirection = (camForward * CurrentInput.z + camRight * CurrentInput.x).normalized;
            }

            Vector3 targetVelocity = moveDirection * Context.Stats.GetMoveSpeed();
            Context.Rb.linearVelocity = new Vector3(targetVelocity.x, Context.Rb.linearVelocity.y, targetVelocity.z);

            if (IsBallRolling && moveDirection != Vector3.zero)
            {
                Vector3 rollAxis = Vector3.Cross(Vector3.up, moveDirection);
                Context.Rb.AddTorque(rollAxis * RollTorque, ForceMode.Force);
            }
            else if (EnableRotation && moveDirection != Vector3.zero)
            {
                Quaternion targetRotation = Quaternion.LookRotation(moveDirection);
                Context.Rb.MoveRotation(Quaternion.Slerp(Context.Rb.rotation, targetRotation, Time.fixedDeltaTime * RotationSpeed));
            }
        }

        protected virtual void ExecuteJump()
        {
            if (Context?.Stats != null)
                Context.Rb.AddForce(Vector3.up * Context.Stats.GetJumpForce(), ForceMode.Impulse);
        }
    }
}