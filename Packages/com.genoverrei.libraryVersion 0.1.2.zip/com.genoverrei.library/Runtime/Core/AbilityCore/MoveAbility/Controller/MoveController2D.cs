namespace Genoverrei.Library.Core
{
    [RequireComponent(typeof(Rigidbody2D))]
    public class MoveController2D : BaseMoveController<IMoveContext2D, BaseMoveAbility2D>, IMoveContext2D
    {
        [Header("Debuger")]
        [ReadOnly]
        [SerializeField] protected Rigidbody2D Rb2;

        protected override IMoveContext2D GetContext() => this;

        Rigidbody2D IMoveContext2D.Rb2 => this.Rb2;

#if UNITY_EDITOR
        protected virtual void OnDrawGizmosSelected()
        {
            if (StartingAbility is ClickMoveAbility2D clickAbility)
            {
                clickAbility.DrawGizmos(transform);
            }
        }

        protected override void OnValidate()
        {
            if (Application.isPlaying) return;

            base.OnValidate();
            Awake();
        }
#endif

        protected override void Awake()
        {
            base.Awake();
            if (Rb2 == null)
            {
                if (!this.TryGetComponent<Rigidbody2D>(out var rigidbody2D)) return;

                Rb2 = rigidbody2D;
            }
        }

        public override float VerticalVelocity => Rb2 != null ? Rb2.linearVelocity.y : 0f;

        public Rigidbody2D GetRigidbody2D() => Rb2;
    }
}