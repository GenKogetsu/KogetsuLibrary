namespace Genoverrei.Library.Core
{
    [RequireComponent(typeof(Rigidbody))]
    public class MoveController3D : BaseMoveController<IMoveContext3D, BaseMoveAbility3D>, IMoveContext3D
    {
        public Rigidbody Rb { get; protected set; }

        protected override IMoveContext3D GetContext() => this;

        Rigidbody IMoveContext3D.Rb => Rb;

#if UNITY_EDITOR
        protected virtual void OnDrawGizmosSelected()
        {
            if (StartingAbility is ClickMoveAbility3D clickAbility)
            {
                clickAbility.DrawGizmos(transform);
            }
        }

        protected override void OnValidate()
        {
            if (Application.isPlaying) return;

            base.OnValidate();
            Awake();
        }
#endif
        protected override void Awake()
        {
            base.Awake();
            
            if (Rb == null)
            {
                if (!this.TryGetComponent<Rigidbody>(out var rigidbody)) return;

                Rb = rigidbody;
            }
        }
        // แทรกไว้ภายในคลาส MoveController3D
        public override float VerticalVelocity => Rb != null ? Rb.linearVelocity.y : 0f; //new (ดึงความเร็วแกน Y ของ 3D)
    }
}