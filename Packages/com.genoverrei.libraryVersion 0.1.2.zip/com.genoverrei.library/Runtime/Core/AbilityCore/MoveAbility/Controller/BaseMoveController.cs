using Genoverrei.Library.Attribute;
using Genoverrei.Library.DesignPatternCore;
using System;
using UnityEngine;

namespace Genoverrei.Library.Core
{
    [RequireComponent(typeof(StatsController))]
    public abstract class BaseMoveController<TContext, TAbility> : MonoBehaviour, IMoveContext
            where TContext : class, IMoveContext
            where TAbility : BaseMoveAbility<TContext>
    {
        [Header("Assign")]
        [field: Required, SerializeField]
        public BasicObserverChannelSO InputObserverChannel { get; protected set; }

        [field: ReadOnly, SerializeField]
        public StatsController Stats { get; protected set; }

        [Header("Abilities")]
        [field: SerializeField] public DirectionMode DirectionMode { get; protected set; }

        [MoveAbilitySelector]
        [SerializeReference] protected TAbility StartingAbility;

        [ReadOnly]
        [SerializeField] protected StateMachine<TContext> StateMachine;

        public Vector3 CurrentDirection { get; set; }
        public Vector3 LastFacingDirection { get; set; } = Vector3.down;
        [field: SerializeField] public bool IsGrounded { get; set; } = true;
        public virtual float VerticalVelocity => 0f;

        protected abstract TContext GetContext();

        Transform IMoveContext.Transform => this.transform;

#if UNITY_EDITOR
        protected virtual void OnValidate()
        {
            if (Application.isPlaying) return;
            this.Awake();
        }
#endif

        protected virtual void Awake()
        {
            AbilitySetUp();
        }

        protected virtual void Update() => StateMachine.Update();

        protected virtual void FixedUpdate() => StateMachine.FixedUpdate();

        protected virtual void AbilitySetUp()
        {
            if (Stats == null && this.TryGetComponent<StatsController>(out var statsController))
                Stats = statsController;

            StateMachine = new StateMachine<TContext>();

            if (StartingAbility != null)
            {
                StartingAbility.Initialize(GetContext());
                StateMachine.ChangeState(StartingAbility);
            }
        }

        protected Func<DirectionMode, byte> ConvertDirectionModeByte = mode => mode switch
        {
            DirectionMode.None => 0,
            DirectionMode.OneDiraction => 1,
            DirectionMode.TwoDiraction => 2,
            DirectionMode.FourDiraction => 4,
            DirectionMode.EightDiraction => 8,
            _ => 0
        };

        public byte CountDirections() => ConvertDirectionModeByte(DirectionMode);

        public Vector3 SnapDirection(Vector3 rawInput)
        {
            if (rawInput == Vector3.zero || DirectionMode == DirectionMode.None) return rawInput;

            byte dirs = CountDirections();
            if (dirs <= 1) return rawInput;

            //new (ตรวจจับอัตโนมัติว่าอินพุตเป็น 2D (X,Y) หรือ 3D (X,Z) เพื่อคำนวณองศาให้ถูกแกน)
            bool is3D = Mathf.Abs(rawInput.y) < 0.001f && Mathf.Abs(rawInput.z) > 0.001f;

            float horizontal = rawInput.x;
            float vertical = is3D ? rawInput.z : rawInput.y;

            float angle = Mathf.Atan2(vertical, horizontal) * Mathf.Rad2Deg;
            float step = 360f / dirs;
            float snappedAngle = Mathf.Round(angle / step) * step;

            float snappedH = Mathf.Cos(snappedAngle * Mathf.Deg2Rad);
            float snappedV = Mathf.Sin(snappedAngle * Mathf.Deg2Rad);

            //new (เก็บค่า Magnitude เดิมที่ถูก Clamp ไว้ เพื่อรักษาความเร็วให้เสถียรทั้งตอนเดินตรงและเดินเฉียง)
            float originalMagnitude = rawInput.magnitude;

            if (is3D)
                return new Vector3(snappedH, rawInput.y, snappedV).normalized * originalMagnitude;
            else
                return new Vector3(snappedH, snappedV, rawInput.z).normalized * originalMagnitude;
        }
    }
}