using System;
using Genoverrei.Library.DesignPatternCore;
using UnityEngine.Accessibility;

namespace Genoverrei.Library.Core;

[Serializable]
public abstract class BaseMoveAbility2D : BaseMoveAbility<IMoveContext2D> , IFixedUpdateState
{
    void IFixedUpdateState.OnFixedUpdate() => OnFixedUpdate();

    protected virtual void OnUpdate()
    {
       
    }

    protected virtual void OnFixedUpdate()
    {
        SetDiraction2D();
    }

    protected virtual void SetDiraction2D()
    {
        if (Context == null) return;

        var velocity = Context.Rb2.linearVelocity;

        CurrentDiraction = velocity.normalized;

        if (velocity.magnitude > 0.01f) LastMoveDiraction = CurrentDiraction;
    }
}
