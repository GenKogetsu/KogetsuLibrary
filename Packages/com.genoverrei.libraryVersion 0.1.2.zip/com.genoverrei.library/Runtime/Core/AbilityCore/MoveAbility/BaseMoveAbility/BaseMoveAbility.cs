using System;
using Genoverrei.Library.DesignPatternCore;

namespace Genoverrei.Library.Core;

[Serializable]
public abstract class BaseMoveAbility<TContext> : BaseState<TContext> , IDirection 
    where TContext : class, IMoveContext
{
    [Header("Input Debuger")]
    [ReadOnly]
    [SerializeField] protected Vector3 CurrentInput;

    [field: ReadOnly, SerializeField]
    public Vector3 CurrentDiraction { get; protected set; }

    [field: ReadOnly, SerializeField]
    public Vector3 LastMoveDiraction { get; protected set; }
    public bool IsJumping { get; protected set; }
    public bool IsCrouching { get; protected set; }

    protected virtual void SetInput(Vector3 input) => CurrentInput = input;
}
