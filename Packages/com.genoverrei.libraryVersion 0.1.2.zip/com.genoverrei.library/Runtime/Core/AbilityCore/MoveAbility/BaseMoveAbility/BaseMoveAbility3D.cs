using System;
using Genoverrei.Library.DesignPatternCore;

namespace Genoverrei.Library.Core;

[Serializable]
public abstract class BaseMoveAbility3D : BaseMoveAbility<IMoveContext3D> , IFixedUpdateState
{
    void IFixedUpdateState.OnFixedUpdate() => OnFixedUpdate();

    protected virtual void OnFixedUpdate()
    {
        SetDiraction3D();
    }

    protected virtual void SetDiraction3D()
    {
        if (Context == null) return;

        var velocity = Context.Rb.linearVelocity;

        CurrentDiraction = velocity.normalized;

        if (velocity.magnitude > 0.01f) LastMoveDiraction = CurrentDiraction;
    }
}
