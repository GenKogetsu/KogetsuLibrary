using System;
using Genoverrei.Library.DesignPatternCore;

namespace Genoverrei.Library.Core
{
    [Serializable]
    public class ClickMoveAbility2D : BaseMoveAbility2D, IEnterState, IExitState, IAbility
    {
        [Header("Click Move Settings")]
        [SerializeField] protected LayerMask GroundLayer;
        [SerializeField] protected LayerMask SolidLayer;

        [Tooltip("ระยะเผื่อก่อนชนเป้าหมายหรือกำแพง")]
        [Range(0.5f, 0.05f)]
        [SerializeField] protected float StoppingDistance = 0.1f;

        [Header("Debug")]
        [SerializeField] protected bool ShowDebugRay = true;
        [Tooltip("ปรับสเกลของเส้น Debug ได้อิสระ (ปกติ = 1)")]
        [SerializeField] protected float DebugShapeScale = 1f;

        protected Vector3 TargetPosition;
        protected bool HasTarget;
        protected Camera MainCamera;
        protected RaycastHit2D Hit;
        protected Collider2D Collider;

        void IEnterState.OnEnter() => OnEnter();
        void IExitState.OnExit() => OnExit();

        protected virtual void OnEnter()
        {
            MainCamera = Camera.main;
            if (Context?.Transform != null && Collider == null)
                Collider = Context.Transform.GetComponent<Collider2D>();

            if (Context.InputObserverChannel != null)
                Context.InputObserverChannel.OnLeftClickChannel += SetDestination;
        }

        protected virtual void OnExit()
        {
            if (Context.InputObserverChannel != null)
                Context.InputObserverChannel.OnLeftClickChannel -= SetDestination;
        }

        protected virtual void SetDestination(ClickData clickData)
        {
            if (MainCamera == null) return;

            Vector3 worldPos = MainCamera.ScreenToWorldPoint(clickData.ClickPosition);
            worldPos.z = 0;

            RaycastHit2D hitInfo = Physics2D.Raycast(worldPos, Vector2.zero, Mathf.Infinity, GroundLayer);

            TargetPosition = hitInfo.collider != null ? hitInfo.point : (Vector2)worldPos;
            HasTarget = true;
        }

        protected override void OnFixedUpdate()
        {
            base.OnFixedUpdate();

            if (!HasTarget || Context?.Stats == null || Context.Rb2 == null || Collider == null) return;

            Vector2 centerPos = Collider.bounds.center;
            float radius = Mathf.Max(Collider.bounds.extents.x, Collider.bounds.extents.y);
            float totalStoppingDistance = radius + StoppingDistance;

            Vector2 targetPos2D = new(TargetPosition.x, TargetPosition.y);
            float distance = Vector2.Distance(centerPos, targetPos2D);

            Vector2 directionToTarget = (targetPos2D - centerPos).normalized;

            // เช็คว่าชนกำแพงด้วยความกว้างตัวละครหรือไม่
            Hit = Physics2D.CircleCast(centerPos, radius, directionToTarget, StoppingDistance, SolidLayer);
            bool hitWall = Hit.collider != null;

            // ถ้าถึงเป้าหมาย หรือ "ชนกำแพง" ให้หยุดทันที
            if (distance <= totalStoppingDistance || hitWall)
            {
                HasTarget = false;
                Context.Rb2.linearVelocity = Vector2.zero;
                return;
            }

            // เคลื่อนที่ตรงไป
            Context.Rb2.linearVelocity = directionToTarget * Context.Stats.GetMoveSpeed();
        }

#if UNITY_EDITOR
        public void DrawGizmos(Transform transform)
        {
            if (Application.isPlaying || !ShowDebugRay) return;

            if (transform.TryGetComponent(out Collider2D col))
            {
                Gizmos.color = Color.cyan;

                // แมปรูปทรงและสเกล
                Gizmos.matrix = Matrix4x4.TRS(transform.position, transform.rotation, transform.lossyScale * DebugShapeScale);

                // วาดรูปร่างเป๊ะๆ จาก Setting ของ Collider2D
                if (col is BoxCollider2D box)
                {
                    Gizmos.DrawWireCube(box.offset, box.size);
                }
                else if (col is CircleCollider2D circle)
                {
                    Gizmos.DrawWireSphere(circle.offset, circle.radius);
                }
                else if (col is CapsuleCollider2D capsule)
                {
                    Gizmos.DrawWireCube(capsule.offset, capsule.size);
                }
                else
                {
                    Gizmos.matrix = Matrix4x4.identity;
                    Gizmos.DrawWireCube(col.bounds.center, col.bounds.size);
                }

                // คืนค่า Matrix เพื่อวาดเส้นทิศทาง
                Gizmos.matrix = Matrix4x4.identity;
                Vector3 center = col.bounds.center;
                Vector3 upDir = transform.up;
                float radius = Mathf.Max(col.bounds.extents.x, col.bounds.extents.y);

                Gizmos.color = Color.yellow;
                Gizmos.DrawLine(center, center + (upDir * (radius + StoppingDistance)));
            }
        }
#endif
    }
}