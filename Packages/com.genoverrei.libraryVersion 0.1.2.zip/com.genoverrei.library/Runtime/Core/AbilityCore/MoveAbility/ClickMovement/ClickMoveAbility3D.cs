using System;
using Genoverrei.Library.DesignPatternCore;

namespace Genoverrei.Library.Core
{
    [Serializable]
    public class ClickMoveAbility3D : BaseMoveAbility3D, IEnterState, IExitState , IAbility
    {
        [Header("Click Move Settings")]
        [SerializeField] protected LayerMask GroundLayer;
        [SerializeField] protected LayerMask SolidLayer;

        [Tooltip("ระยะเผื่อก่อนชนเป้าหมายหรือกำแพง")]
        [Range(0.5f, 0.01f)]
        [SerializeField] protected float StoppingDistance = 0.1f;

        [Range(15f, 100f)]
        [SerializeField] protected float RotationSpeed = 15f;

        [Header("Debug")]
        [SerializeField] protected bool ShowDebugRay = true;
        [Tooltip("ปรับสเกลของเส้น Debug ได้อิสระ (ปกติ = 1)")]
        [SerializeField] protected float DebugShapeScale = 1f;

        protected Vector3 TargetPosition;
        protected bool HasTarget;
        protected Camera MainCamera;
        protected RaycastHit Hit;
        protected Collider Collider;

        void IEnterState.OnEnter() => OnEnter();
        void IExitState.OnExit() => OnExit();

        protected virtual void OnEnter()
        {
            MainCamera = Camera.main;
            if (Context?.Transform != null && Collider == null) Collider = Context.Transform.GetComponent<Collider>();

            if (Context.InputObserverChannel != null)
                Context.InputObserverChannel.OnLeftClickChannel += SetDestination;
        }

        protected virtual void OnExit()
        {
            if (Context.InputObserverChannel != null)
                Context.InputObserverChannel.OnLeftClickChannel -= SetDestination;
        }

        protected override void OnFixedUpdate()
        {
            base.OnFixedUpdate();

            if (!HasTarget || Context?.Stats == null || Context.Rb == null || Collider == null) return;

            Vector3 centerPos = Collider.bounds.center;
            float radius = Mathf.Max(Collider.bounds.extents.x, Collider.bounds.extents.z);
            float totalStoppingDistance = radius + StoppingDistance;

            Vector3 targetPosFlat = new(TargetPosition.x, centerPos.y, TargetPosition.z);
            float distance = Vector3.Distance(centerPos, targetPosFlat);

            Vector3 directionToTarget = (targetPosFlat - centerPos).normalized;

            bool hitWall = Physics.SphereCast(centerPos, radius, directionToTarget, out Hit, StoppingDistance, SolidLayer);

            if (distance <= totalStoppingDistance || hitWall)
            {
                HasTarget = false;
                Context.Rb.linearVelocity = new(0, Context.Rb.linearVelocity.y, 0);
                return;
            }

            Vector3 targetVelocity = directionToTarget * Context.Stats.GetMoveSpeed();
            Context.Rb.linearVelocity = new(targetVelocity.x, Context.Rb.linearVelocity.y, targetVelocity.z);

            if (directionToTarget != Vector3.zero)
            {
                Quaternion targetRotation = Quaternion.LookRotation(directionToTarget);
                Context.Rb.MoveRotation(Quaternion.Slerp(Context.Rb.rotation, targetRotation, Time.fixedDeltaTime * RotationSpeed));
            }
        }

#if UNITY_EDITOR
        public void DrawGizmos(Transform transform)
        {
            if (Application.isPlaying || !ShowDebugRay) return;

            if (transform.TryGetComponent(out Collider col))
            {
                Gizmos.color = Color.cyan;

                // แมปรูปทรงและสเกลของ Transform มาใช้กับ Gizmos ทำให้ถ้ายืดวงรี เส้นก็จะวงรีตาม
                Gizmos.matrix = Matrix4x4.TRS(transform.position, transform.rotation, transform.lossyScale * DebugShapeScale);

                // วาดรูปร่างเป๊ะๆ จาก Setting ของ Collider
                if (col is BoxCollider box)
                {
                    Gizmos.DrawWireCube(box.center, box.size);
                }
                else if (col is SphereCollider sphere)
                {
                    Gizmos.DrawWireSphere(sphere.center, sphere.radius);
                }
                else if (col is CapsuleCollider capsule)
                {
                    Gizmos.DrawWireCube(capsule.center, new Vector3(capsule.radius * 2, capsule.height, capsule.radius * 2));
                }
                else if (col is MeshCollider meshCol && meshCol.sharedMesh != null)
                {
                    Gizmos.DrawWireMesh(meshCol.sharedMesh, Vector3.zero, Quaternion.identity, Vector3.one);
                }
                else
                {
                    Gizmos.matrix = Matrix4x4.identity;
                    Gizmos.DrawWireCube(col.bounds.center, col.bounds.size);
                }

                // คืนค่า Matrix เพื่อวาดเส้นทิศทางตรงๆ ไม่ให้เบี้ยว
                Gizmos.matrix = Matrix4x4.identity;
                Vector3 center = col.bounds.center;
                Vector3 forward = transform.forward;
                float radius = Mathf.Max(col.bounds.extents.x, col.bounds.extents.z);

                Gizmos.color = Color.yellow;
                Gizmos.DrawLine(center, center + (forward * (radius + StoppingDistance)));
            }
        }
#endif
        protected virtual void SetDestination(ClickData clickData)
        {
            if (MainCamera == null) return;

            Ray ray = MainCamera.ScreenPointToRay(clickData.ClickPosition);
            if (Physics.Raycast(ray, out Hit, 1000f, GroundLayer))
            {
                TargetPosition = Hit.point;
                HasTarget = true;
            }
        }
    }
}