public enum DirectionMode
{
	None,
    OneDiraction,
    TwoDiraction,
    FourDiraction,
    EightDiraction,
}