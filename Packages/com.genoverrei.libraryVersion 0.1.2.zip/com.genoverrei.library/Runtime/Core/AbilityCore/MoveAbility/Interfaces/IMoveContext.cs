namespace Genoverrei.Library.Core;

using Genoverrei.Library.DesignPatternCore;

public interface IMoveContext
{
    Transform Transform { get; }
    StatsController Stats { get; }
    BasicObserverChannelSO InputObserverChannel { get; }
    Vector3 CurrentDirection { get; set; }
    Vector3 LastFacingDirection { get; set; } //new (จำทิศทางล่าสุด เพื่อไม่ให้แอนิเมชันเพี้ยนเวลาหยุดเดินแล้วกระโดด)
    bool IsGrounded { get; set; } //new (สถานะการยืนบนพื้น ให้ Ability เป็นตัวสั่งเปิด/ปิด)
    float VerticalVelocity { get; } //new (ดึงความเร็วแนวดิ่งเพื่อเช็คว่ากำลังพุ่งขึ้นหรือร่วงลง)
    Vector3 SnapDirection(Vector3 rawInput);
}

public interface IMoveContext2D : IMoveContext
{
    Rigidbody2D Rb2 { get; }
}

public interface IMoveContext3D : IMoveContext
{
    Rigidbody Rb { get; }
}