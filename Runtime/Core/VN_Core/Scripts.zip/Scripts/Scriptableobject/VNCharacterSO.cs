using System;
using System.Collections.Generic;
using UnityEngine;
using NaughtyAttributes;

namespace Genoverrei.Library.Core
{
    /// <summary>
    /// <para> Summary : </para>
    /// <para> (TH) : ไฟล์ข้อมูลที่เก็บรวบรวม Emotion แพ็คเกจและภาพทั้งหมดของตัวละคร </para>
    /// <para> (EN) : Data file containing all emotion packages and sprites for a character. </para>
    /// </summary>
    /// <summary>
    /// <para> Summary : </para>
    /// <para> (TH) : ไฟล์ข้อมูลตัวละคร แยกการจัดการระหว่าง Emotion (หน้าตา/เอฟเฟกต์) และ Animation (การเคลื่อนที่) </para>
    /// <para> (EN) : Character data file, separating Emotion (face/effects) and Animation (movement) management. </para>
    /// </summary>
    /// <summary>
    /// <para> Summary : </para>
    /// <para> (TH) : ไฟล์ข้อมูลตัวละคร แยกการจัดการระหว่าง Emotion (หน้าตา) และ Animation (การเคลื่อนที่) </para>
    /// <para> (EN) : Character data file, separating Emotion (face) and Animation (movement) management. </para>
    /// </summary>
    [CreateAssetMenu(fileName = "NewVNCharacter", menuName = "GenoverreiLibrary/Core/VN/Character")]
    public class VNCharacterSO : ScriptableObject
    {
        [Serializable]
        public struct VNEmotionData
        {
            [Required]
            public Sprite EmoteSprite;

            [Required]
            public Sprite EmoteIcon;

            [Required]
            public AnimationClip EmoteClip;
        }

        [Serializable]
        public struct VNBehaviorAnimationData
        {
            [Required]
            public AnimationClip BehaviorAnimationClip;
        }

        [Serializable]
        public struct VNSoundEffectData
        {
            [Required]
            public AudioClip SoundEffectClip;
        }

        public string CharacterName;
        public ushort CharacterID;

        [Header("Character Assets")]
        public List<VNEmotionData> Emotions = new();
        public List<VNBehaviorAnimationData> BehaviorAnimations = new();
        public List<VNSoundEffectData> SoundEffects = new();

        private Dictionary<string, VNEmotionData> _dicEmotions;
        private Dictionary<string, VNBehaviorAnimationData> _dicAnimations;
        private Dictionary<string, VNSoundEffectData> _dicSoundEffects;

        public Action<string> OnVNEmotionChannel;
        public Action<string> OnVNAnimationChannel;
        public Action<string> OnVNSoundEffectChannel;

        public void SendVNEmotionSignel(string emotionName) => OnVNEmotionChannel?.Invoke(emotionName);

        public void SendVNAnimationSignal(string animationName) => OnVNAnimationChannel?.Invoke(animationName);

        public void SendVNSoundEffectSignel(string soundEffectName) => OnVNSoundEffectChannel?.Invoke(soundEffectName);

        /// <summary>
        /// <para> Summary : </para>
        /// <para> (TH) : ค้นหาข้อมูล Emotion จากชื่อที่ระบุ </para>
        /// <para> (EN) : Finds the emotion data by the specified name. </para>
        /// <para> Return : </para>
        /// <para> (TH) : ข้อมูล Emotion ที่พบ หรือ null หากไม่พบ </para>
        /// </summary>
        public VNEmotionData? GetEmotion(string name) => _dicEmotions.TryGetValue(name, out var data) ? data : null;

        /// <summary>
        /// <para> Summary : </para>
        /// <para> (TH) : ค้นหาข้อมูล Animation จากชื่อที่ระบุ </para>
        /// <para> (EN) : Finds the animation data by the specified name. </para>
        /// <para> Return : </para>
        /// <para> (TH) : ข้อมูล Animation ที่พบ หรือ null หากไม่พบ </para>
        /// </summary>
        public VNBehaviorAnimationData? GetAnimation(string name) => _dicAnimations.TryGetValue(name, out var data) ? data : null;

        public VNSoundEffectData? GetSoundEffect(string name) => _dicSoundEffects.TryGetValue(name, out var data) ? data : null;

        private void Awake()
        {
            _dicEmotions = InitializeDictionary(Emotions, emote => emote.EmoteClip, "Emotion");
            _dicAnimations = InitializeDictionary(BehaviorAnimations, anime => anime.BehaviorAnimationClip, "Animation");
            _dicSoundEffects = InitializeDictionary(SoundEffects, effect => effect.SoundEffectClip, "SoundEffect");
        }

        private Dictionary<string, T> InitializeDictionary<T>(List<T> list, Func<T, UnityEngine.Object> getAssetFunc, string typeName)
        {
            var dictionary = new Dictionary<string, T>();

            foreach (var item in list)
            {
                var asset = getAssetFunc(item);

                if (asset == null)
                {
#if UNITY_EDITOR
                    Debug.LogWarning($"<b><color=red>[Skip {typeName}]</color></b>" + Environment.NewLine
                        + $"<b><u><color=cyan>because</color></u></b> Asset Clip is <b><color=yellow><i>Null!!</i></color></b>");
#endif
                    continue;
                }

                var assetName = asset.name;

                if (dictionary.ContainsKey(assetName))
                {
#if UNITY_EDITOR
                    Debug.LogWarning($"<b><color=red>[Skip {assetName}]</color></b>" + Environment.NewLine
                       + $"<b><u><color=cyan>because</color></u></b> {typeName} is already available.");
#endif
                    continue;
                }

                dictionary.Add(assetName, item);
            }

            return dictionary;
        }
    }
}